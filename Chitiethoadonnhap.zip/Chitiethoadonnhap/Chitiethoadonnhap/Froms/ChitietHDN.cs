﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chitiethoadonnhap.Froms
{
    public partial class frmChitietHDN : Form
    {
        public frmChitietHDN()
        {
            InitializeComponent();
            Class.Function.Connect();
        }

        private void frmChitietHDN_Load(object sender, EventArgs e)
        {
            txtsohdn.Enabled = false;
            btnluu.Enabled = false;
            btnboqua.Enabled = false;
            txtsoluong.ReadOnly = true;
            txtmahang.ReadOnly = true;
            txtdongia.ReadOnly = true;
            txtthanhtien.ReadOnly = true;
            txtgiamgia.ReadOnly = true;
            Load_DataGridView();
        }
        DataTable tblcthdn;
        private void Load_DataGridView()
        {
            string sql;
            sql = "select * from tblChitiethoadonnhap";
            tblcthdn = Class.Function.GetDataToTable(sql);
            dgridchitietHDN.DataSource = tblcthdn;
            dgridchitietHDN.Columns[0].HeaderText = "Số HDN";
            dgridchitietHDN.Columns[1].HeaderText = "Mã hàng";
            dgridchitietHDN.Columns[2].HeaderText = "Số lượng";
            dgridchitietHDN.Columns[3].HeaderText = "Đơn giá";
            dgridchitietHDN.Columns[4].HeaderText = "Giảm giá";
            dgridchitietHDN.Columns[5].HeaderText = "Thành tiền";
            // Không cho phép thêm mới dữ liệu trực tiếp trên lưới
            dgridchitietHDN.AllowUserToAddRows = false;
            // Không cho phép sửa dữ liệu trực tiếp trên lưới
            dgridchitietHDN.EditMode = DataGridViewEditMode.EditProgrammatically;
        }

        private void dgridchitietHDN_Click(object sender, EventArgs e)
        {

            if (btnthem.Enabled == false)
            {
                MessageBox.Show("Đang ở chế độ thêm mới", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (tblcthdn.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            txtsohdn.Text = dgridchitietHDN.CurrentRow.Cells["SoHDN"].Value.ToString();
            txtmahang.Text = dgridchitietHDN.CurrentRow.Cells["Mahang"].Value.ToString();
            // thiếu làm tiếp để hiển thị địa chỉ và số điện thoại
            txtdongia.Text = dgridchitietHDN.CurrentRow.Cells["Dongia"].Value.ToString();
            txtsoluong.Text = dgridchitietHDN.CurrentRow.Cells["Soluong"].Value.ToString();
            txtgiamgia.Text = dgridchitietHDN.CurrentRow.Cells["Giamgia"].Value.ToString();
            txtthanhtien.Text = dgridchitietHDN.CurrentRow.Cells["Thanhtien"].Value.ToString();
            btnsua.Enabled = true;
            btnxoa.Enabled = true;
            btnboqua.Enabled = true;
        }

        private void btnthem_Click(object sender, EventArgs e)
        {
            btnthem.Enabled = false;
            btnsua.Enabled = false;
            btnxoa.Enabled = false;
            btnluu.Enabled = true;
            btnboqua.Enabled = true;
            txtsohdn.Enabled = true;
            txtmahang.Enabled = true;
            txtsohdn.Focus();
            txtsoluong.Text = "";
            txtdongia.Text = "";
            txtgiamgia.Text = "";
            txtthanhtien.Enabled = false;
        }

        private void resetvalue()
        {
            txtsohdn.Text = "";
            txtmahang.Text = "";
            txtdongia.Text = "0";
            txtgiamgia.Text="0";
            txtsoluong.Text="";
            txtthanhtien.Text="0";
            txtsoluong.Enabled=false;
            txtdongia.Enabled=false;
            txtgiamgia.Enabled=false;
            txtthanhtien.Enabled=false;
        }

        private void btnboqua_Click(object sender, EventArgs e)
        {
            resetvalue();
            btnboqua.Enabled=false;
            btnluu.Enabled = false;
            btnthem.Enabled = true;
            btnsua.Enabled = true;
            btnxoa.Enabled = true;
            txtsohdn.Enabled=false;
            txtmahang.Enabled=false;
        }

        private void btnluu_Click(object sender, EventArgs e)
        {
            string sql;
            if(txtsohdn.Text == "")
            {
                MessageBox.Show("Bạn phải nhập số HĐN", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtsohdn.Focus();
                return;
            }
            if (txtmahang.Text == "")
            {
                MessageBox.Show("Bạn phải nhập mã hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtmahang.Focus();
                return;
            }
            if (txtdongia.Text == "")
            {
                MessageBox.Show("Bạn phải nhập đơn giá", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtdongia.Focus();
                return;
            }
            if (txtsoluong.Text == "")
            {
                MessageBox.Show("Bạn phải nhập số lượng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtsoluong.Focus();
                return;
            }
            // ktra ma bi trùng
             sql = "SELECT MaHDN, Mahang FROM tblChitiethoadonnhap WHERE MaHDN = N'" + txtsohdn.Text.Trim() + "' AND Mahang = N'" + txtmahang.Text.Trim() + "'";
            if (Class.Function.checkkey(sql))
            {
                MessageBox.Show("Mã HDN cùng mã hàng này đã tồn tại.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtsohdn.Focus();
                txtmahang.Focus();
                return;
            }
            sql = "INSERT INTO tblChitiethoadonnhap(MaHDN, Mahang, Dongia, Soluong, Giamgia ,Thanhtien) values(N'" + txtsohdn.Text.Trim() + "',N'" + txtmahang.Text.Trim() + "'," + txtdongia.Text + "," + txtsoluong.Text + ", " + txtgiamgia.Text + ", " + txtthanhtien.Text + " )";
            Class.Function.checkkey(sql);
            Load_DataGridView();
            resetvalue();
            btnxoa.Enabled = true;
            btnthem.Enabled = true;
            btnsua.Enabled = true;
            btnboqua.Enabled = false;
            btnluu.Enabled = false;
            txtsohdn.Enabled = false;

        }

        private void btnsua_Click(object sender, EventArgs e)
        {
            string sql, gt;
            if (tblcthdn.Rows.Count == 0)
            {
                MessageBox.Show("Không còn dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtsohdn.Text == "")
            {
                MessageBox.Show("Bạn chưa chọn bản ghi nào", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
               txtsohdn.Focus();
                return;
            }
            if (txtmahang.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn chưa chọn bản ghi nào", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtmahang.Focus();
                return;
            }
            if (txtsoluong.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập số lượng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtsoluong.Focus();
                return;
            }
            if (txtdongia.Text.Trim().Length == 0)
            {
                MessageBox.Show("Bạn phải nhập đơn giá", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtdongia.Focus();
                return;
            }


            sql = "UPDATE tblChitiethoadonnhap SET SoHDN = N'" + txtsohdn.Text.Trim() + "', Mahang = N'" + txtmahang.Text.Trim() + "', Soluong = '" + txtsoluong.Text + "', Dongia = '" + txtdongia.Text + "', Giamgia = '" + txtgiamgia.Text + "', Thanhtien = '" + txtthanhtien.Text + "' WHERE SoHDN = N'" + txtsohdn.Text.Trim() + "' AND Mahang = N'" + txtmahang.Text.Trim() + "'";
            Class.Function.runsql(sql);
            Load_DataGridView();
            resetvalue();
            btnboqua.Enabled = false;
        }

        private void btnxoa_Click(object sender, EventArgs e)
        {
            string sql;
            if (tblcthdn.Rows.Count == 0)
            {
                MessageBox.Show("Không còn dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (txtsohdn.Text == "" && txtmahang.Text =="")
            {
                MessageBox.Show("Bạn chưa chọn bản ghi nào", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show("Bạn có muốn xóa không?", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                sql = "DELETE FROM tblChitiethoadonnhap WHERE SoHDN = N'" + txtsohdn.Text + "' AND Mahang = N'" + txtmahang.Text + "'"; Class.Function.runsql(sql);
                Load_DataGridView();
                resetvalue();
            }
        }
      

        private void btndong_Click_1(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn đóng cửa sổ này không?", "Xác nhận đóng form", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
