﻿using QLBH02.Class;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBH02.Forms
{
    public partial class frmkhachhang : Form
    {
        public frmkhachhang()
        {
            InitializeComponent();
        }

        private void Khachhang_Load(object sender, EventArgs e)

        {
            Class.Function.Connect();
            // TODO: This line of code loads data into the 'cuaHangMyPhamDataSet.tblKhachhang' table. You can move, or remove it, as needed.
            this.tblKhachhangTableAdapter.Fill(this.cuaHangMyPhamDataSet.tblKhachhang);
            Class.Function.Connect();
            txtmakh.Enabled = false;
            btnluu.Enabled = false;
            btnboqua.Enabled = false;
            Load_DataGridView();
        }
        DataTable tblkh;
        private void Load_DataGridView()
        {
            string sql;
            sql = "select * from tblKhachhang";
             tblkh = Class.Function.GetDataToTable(sql);
            Dgrikhachhang.DataSource = tblkh;
            Dgrikhachhang.Columns[0].HeaderText = "Mã khách ";
            Dgrikhachhang.Columns[1].HeaderText = "Tên khách ";
            Dgrikhachhang.Columns[2].HeaderText = "Địa chỉ";
            Dgrikhachhang.Columns[3].HeaderText = "Số điện thoại";
            // Không cho phép thêm mới dữ liệu trực tiếp trên lưới
            Dgrikhachhang.AllowUserToAddRows = false;
            // Không cho phép sửa dữ liệu trực tiếp trên lưới
            Dgrikhachhang.EditMode = DataGridViewEditMode.EditProgrammatically;
        }

        private void Dgrikhachhang_Click(object sender, EventArgs e)
        {
            if(btnthem.Enabled== false)
            {
                MessageBox.Show("Đang ở chế độ thêm mới", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                 return;
            }
            if (tblkh.Rows.Count ==0)
            {
                MessageBox.Show("Không có dữ liệu", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            txtmakh.Text = Dgrikhachhang.CurrentRow.Cells["maKHDataGridViewTextBoxColumn"].Value.ToString();
            txttenkhach.Text = Dgrikhachhang.CurrentRow.Cells["tenkhachDataGridViewTextBoxColumn"].Value.ToString();
            // thiếu làm tiếp để hiển thị địa chỉ và số điện thoại
            txtdiachi.Text = Dgrikhachhang.CurrentRow.Cells["diachiDataGridViewTextBoxColumn"].Value.ToString();
            masksdt.Text = Dgrikhachhang.CurrentRow.Cells["dienthoaiDataGridViewTextBoxColumn"].Value.ToString();
            btnsua.Enabled = true;
            btnxoa.Enabled = true;
            btnboqua.Enabled = true;

        }

        private void btnthem_Click(object sender, EventArgs e)
        {
            btnthem.Enabled = false;
            btnsua.Enabled=false;
            btnxoa.Enabled=false;
            btnluu.Enabled=true;
            btnboqua.Enabled=true;
            txtmakh.Enabled=true;
            txtmakh.Focus();
            txttenkhach.Text = "";
            txtdiachi.Text = "";
            masksdt.Text = "";
         
        }
        private void resetvalue()
        {
            txtmakh.Text = "";
            txttenkhach.Text = "";
            txtdiachi.Text = "";
            masksdt.Text = "";
        }

        private void btnboqua_Click(object sender, EventArgs e)
        {
            resetvalue();

            btnboqua.Enabled = false;
            btnluu.Enabled = false;
            btnthem.Enabled=true;
            btnsua.Enabled = true;
            btnxoa.Enabled=true;
            txtmakh.Enabled = false;
           

        }

        private void btnluu_Click(object sender, EventArgs e)
        {
            // kiểm tra nhập đủ
            string sql;
            if(txtmakh.Text =="")
            {
                MessageBox.Show("Bạn phải nhập mã khách hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtmakh.Focus();
                return;
            }
            if(txttenkhach.Text == "")
            {
                MessageBox.Show("Bạn phải nhập tên khách hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txttenkhach.Focus();
                return;
            }
            if(txtdiachi.Text == "")
            {
                MessageBox.Show("Bạn phải nhập địa chỉ ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtdiachi.Focus();
                return;
            }
            if (masksdt.Text == "(   )     -")
            {
                MessageBox.Show("Bạn phải nhập số điện thoại ", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                masksdt.Focus();
                return;
            }

            // ktra ma bi trùng
            sql = "select MaKH from tblKhachhang where MaKH=N'" + txtmakh.Text.Trim() + "'";
            if(Class.Function.checkkey(sql))
            {
                MessageBox.Show("Đã có mã khách hàng này", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtmakh.Focus();
                return;
            }
            sql = "INSERT INTO tblKhachhang(MaKH, Tenkhach, Diachi, Dienthoai ) values(N'" + txtmakh.Text.Trim() + "',N'" + txttenkhach.Text.Trim() + "',N'" + txtdiachi.Text.Trim() + "', '" + masksdt.Text + "')";
            Class.Function.checkkey(sql);
            Load_DataGridView();
            resetvalue();
            btnxoa.Enabled = true;
            btnthem.Enabled = true;
            btnsua.Enabled = true;
            btnboqua.Enabled = false;
            btnluu.Enabled = false;
            txtmakh.Enabled =false;
        }

        private void btndong_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnsua_Click(object sender, EventArgs e)
        {
                string sql, gt;
                if (tblkh.Rows.Count == 0)
                {
                    MessageBox.Show("Không còn dữ liệu!", "Thông báo", MessageBoxButtons.OK,MessageBoxIcon.Information);
                    return;
                }
                if (txtmakh.Text == "")
                {
                    MessageBox.Show("Bạn chưa chọn bản ghi nào", "Thông báo",MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                if (txttenkhach.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Bạn phải nhập tên nhân viên", "Thông báo",MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txttenkhach.Focus();
                    return;
                }
                if (txtdiachi.Text.Trim().Length == 0)
                {
                    MessageBox.Show("Bạn phải nhập địa chỉ", "Thông báo", MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    txtdiachi.Focus();
                    return;
                }
                if (masksdt.Text == "(   )     -")
                {
                    MessageBox.Show("Bạn phải nhập điện thoại", "Thông báo",MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    masksdt.Focus();
                    return;
                }
                 sql = "UPDATE tblKhachhang SET Tenkhach = N'" + txttenkhach.Text.Trim() + "', Diachi = N'" + txtdiachi.Text.Trim() + "', Dienthoai = '" + masksdt.Text.Trim() + "' WHERE MaKH = N'" + txtmakh.Text.Trim() + "'";
                 Class.Function.runsql(sql);
                Load_DataGridView();
                resetvalue();
                btnboqua.Enabled = false;
            }

        private void btnxoa_Click(object sender, EventArgs e)
        {
            string sql;
            if (tblkh.Rows.Count == 0)
            {
                MessageBox.Show("Không còn dữ liệu!", "Thông báo", MessageBoxButtons.OK,MessageBoxIcon.Information);
                return;
            }
            if (txtmakh.Text == "")
            {
                MessageBox.Show("Bạn chưa chọn bản ghi nào", "Thông báo",MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show("Bạn có muốn xóa không?", "Thông báo",MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                sql = "DELETE tblKhachhang WHERE MaKH=N'" + txtmakh.Text + "'";
                Class.Function.runsql(sql);
                Load_DataGridView();
                resetvalue();
            }
        }
    }
    }

